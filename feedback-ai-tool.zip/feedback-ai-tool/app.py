from flask import Flask, render_template, request
from collections import Counter
import re
import docx
import PyPDF2
import language_tool_python

app = Flask(__name__)
document_history = []

tool = language_tool_python.LanguageTool("en-GB")


def extract_text_from_txt(file):
    return file.read().decode("utf-8", errors="ignore")


def extract_text_from_docx(file):
    document = docx.Document(file)
    return "\n".join([paragraph.text for paragraph in document.paragraphs])


def extract_text_from_pdf(file):
    pdf_reader = PyPDF2.PdfReader(file)
    pages = []

    for page in pdf_reader.pages:
        pages.append(page.extract_text() or "")

    return "\n".join(pages)


def extract_text(file, filename):
    filename = filename.lower()

    if filename.endswith(".txt"):
        return extract_text_from_txt(file)
    elif filename.endswith(".docx"):
        return extract_text_from_docx(file)
    elif filename.endswith(".pdf"):
        return extract_text_from_pdf(file)
    else:
        return None


def clean_text(text):
    text = text.replace("\r", "\n")
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def get_metrics(text):
    words = re.findall(r"\b\w+\b", text)
    sentences = [s for s in re.split(r"[.!?]+", text) if s.strip()]
    paragraphs = [p for p in text.split("\n") if p.strip()]

    return {
        "word_count": len(words),
        "sentence_count": len(sentences),
        "paragraph_count": len(paragraphs),
        "avg_sentence_length": round(len(words) / len(sentences), 2) if sentences else 0
    }


def get_repeated_words(text):
    words = re.findall(r"\b[a-zA-Z]{4,}\b", text.lower())
    counts = Counter(words)
    repeated = [f"{word} appears {count} times" for word, count in counts.items() if count >= 5]

    if not repeated:
        return ["No heavily repeated words found."]

    return repeated[:10]


def get_structure_feedback(text, metrics):
    feedback = []

    if metrics["paragraph_count"] < 3:
        feedback.append("Try splitting the writing into more paragraphs.")

    if metrics["avg_sentence_length"] > 25:
        feedback.append("Some sentences look too long. Try making them shorter and clearer.")

    if metrics["avg_sentence_length"] < 8 and metrics["sentence_count"] > 5:
        feedback.append("Some sentences may be too short or choppy. Try combining related ideas.")

    if len(text) < 500:
        feedback.append("The document may need more detail or explanation.")

    if not feedback:
        feedback.append("The document demonstrates a clear overall structure.")

    return feedback


def get_content_feedback(text):
    feedback = []
    lower_text = text.lower()

    if "introduction" not in lower_text:
        feedback.append("Consider adding an introduction.")

    if "conclusion" not in lower_text:
        feedback.append("Consider adding a conclusion.")

    if "reference" not in lower_text and "bibliography" not in lower_text:
        feedback.append("If this is academic work, consider adding references.")

    if "analysis" not in lower_text:
        feedback.append("Consider including more critical analysis.")

    if "discussion" not in lower_text:
        feedback.append("A discussion section could strengthen the depth of your work.")

    if "method" not in lower_text and "methodology" not in lower_text:
        feedback.append("Consider adding a methodology section if relevant.")

    if not feedback:
        feedback.append("No obvious missing sections were found.")

    return feedback


def get_grammar_feedback(text):
    matches = tool.check(text)

    if not matches:
        return [{
            "issue": "No obvious spelling, grammar, or punctuation issues were detected.",
            "before": "",
            "error": "",
            "after": "",
            "suggestion": ""
        }]

    feedback = []
    seen = set()

    for match in matches:
        start = match.offset
        end = match.offset + match.error_length

        before = text[max(0, start - 60):start]
        error_text = text[start:end]
        after = text[end:end + 60]

        issue = match.message.replace("Possible typo:", "").strip()
        suggestion = ", ".join(match.replacements[:3]) if match.replacements else "No suggestion available"

        key = f"{issue}-{error_text}-{suggestion}"

        if key not in seen:
            seen.add(key)
            feedback.append({
                "issue": issue,
                "before": before,
                "error": error_text,
                "after": after,
                "suggestion": suggestion
            })

        if len(feedback) >= 8:
            break

    return feedback


def get_overall_feedback(metrics, structure_feedback, content_feedback, grammar_feedback):
    score = 100

    if "clear overall structure" not in " ".join(structure_feedback).lower():
        score -= len(structure_feedback) * 8

    if "no obvious missing sections" not in " ".join(content_feedback).lower():
        score -= len(content_feedback) * 8

    if grammar_feedback and "no obvious" not in grammar_feedback[0]["issue"].lower():
        score -= 10

    if metrics["avg_sentence_length"] > 25:
        score -= 5

    if metrics["paragraph_count"] < 3:
        score -= 5

    score = max(score, 0)

    if score >= 80:
        summary = "This document is fairly strong overall, with a clear foundation and only minor areas for improvement."
    elif score >= 60:
        summary = "This document is decent, but there are several areas that could be improved."
    else:
        summary = "This document needs more improvement in structure and writing quality."

    return score, summary


def analyse_document(file):
    extracted_text = extract_text(file, file.filename)

    if extracted_text is None:
        return None, "Only TXT, DOCX, and PDF files are supported."

    text = clean_text(extracted_text)

    if not text:
        return None, "No readable text was found in the file."

    metrics = get_metrics(text)
    repeated_words = get_repeated_words(text)
    structure_feedback = get_structure_feedback(text, metrics)
    content_feedback = get_content_feedback(text)
    grammar_feedback = get_grammar_feedback(text)

    overall_score, overall_summary = get_overall_feedback(
        metrics,
        structure_feedback,
        content_feedback,
        grammar_feedback
    )

    result = {
        "id": len(document_history),
        "filename": file.filename,
        "text": text,
        "metrics": metrics,
        "repeated_words": repeated_words,
        "structure_feedback": structure_feedback,
        "content_feedback": content_feedback,
        "grammar_feedback": grammar_feedback,
        "overall_score": overall_score,
        "overall_summary": overall_summary
    }

    return result, None


@app.route("/", methods=["GET", "POST"])
def home():
    text = None
    metrics = None
    repeated_words = None
    structure_feedback = None
    content_feedback = None
    grammar_feedback = None
    overall_score = None
    overall_summary = None
    error = None

    if request.method == "POST":
        file = request.files.get("document")

        if not file or file.filename == "":
            error = "Please upload a file."
        else:
            result, error = analyse_document(file)

            if result:
                document_history.append(result)

                text = result["text"]
                metrics = result["metrics"]
                repeated_words = result["repeated_words"]
                structure_feedback = result["structure_feedback"]
                content_feedback = result["content_feedback"]
                grammar_feedback = result["grammar_feedback"]
                overall_score = result["overall_score"]
                overall_summary = result["overall_summary"]

    return render_template(
        "index.html",
        text=text,
        metrics=metrics,
        repeated_words=repeated_words,
        structure_feedback=structure_feedback,
        content_feedback=content_feedback,
        grammar_feedback=grammar_feedback,
        overall_score=overall_score,
        overall_summary=overall_summary,
        error=error,
        history=document_history
    )


@app.route("/history/<int:doc_id>")
def view_history(doc_id):
    if doc_id < 0 or doc_id >= len(document_history):
        return render_template("index.html", history=document_history)

    saved = document_history[doc_id]

    return render_template(
        "index.html",
        text=saved["text"],
        metrics=saved["metrics"],
        repeated_words=saved["repeated_words"],
        structure_feedback=saved["structure_feedback"],
        content_feedback=saved["content_feedback"],
        grammar_feedback=saved["grammar_feedback"],
        overall_score=saved["overall_score"],
        overall_summary=saved["overall_summary"],
        error=None,
        history=document_history
    )


if __name__ == "__main__":
    app.run(debug=True)